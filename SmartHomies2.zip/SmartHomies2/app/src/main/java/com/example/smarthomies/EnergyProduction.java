package com.example.smarthomies;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class EnergyProduction extends AppCompatActivity {

    private Button btnBackEP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_energy_production);

        btnBackEP = findViewById(R.id.btnBackEP);
        btnBackEP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EnergyProduction.this, Menu.class);
                startActivity(intent);
            }
        });

    }
}